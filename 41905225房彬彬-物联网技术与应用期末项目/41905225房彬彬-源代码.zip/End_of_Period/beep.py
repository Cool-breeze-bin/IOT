import winsound
import time
winsound.Beep(800,1000)
time.sleep(1)
winsound.Beep(1000,1000)
# 其中600表示声音大小，1000表示发生时长，1000为1秒